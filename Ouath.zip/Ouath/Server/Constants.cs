﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server
{
    public static class Constants
    {
        public const string Issuer = Audiance;
        public const string Audiance = "https://localhost:44392/"; //server local address
        public const string Secret = "sdsdffdsffrgdfrfgrgsdsdewecasffdvdrafe"; //secretkey
    }
}
